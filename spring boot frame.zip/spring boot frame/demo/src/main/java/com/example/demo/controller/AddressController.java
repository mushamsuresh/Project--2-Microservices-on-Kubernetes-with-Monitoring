package com.example.demo.controller;

import com.example.demo.logic.AddressComparator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AddressController {

    private final AddressComparator comparator = new AddressComparator();

    @GetMapping("/compare")
    public String compareAddresses(
            @RequestParam String customerAddress,
            @RequestParam String nakAddress) {

        boolean match = comparator.compare(customerAddress, nakAddress);

        if (match) {
            return "✅ Addresses MATCH (house number and street are the same)";
        } else {
            return "❌ Addresses DO NOT match";
        }
    }
}
