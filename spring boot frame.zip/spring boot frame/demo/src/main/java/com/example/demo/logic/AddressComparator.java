package com.example.demo.logic;

import java.util.ArrayList;
import java.util.List;

public class AddressComparator {

    public boolean compare(String customerAddress, String nakAddress) {
        if (customerAddress == null || nakAddress == null) return false;

        // ---- NAK address (must use '!' separators) ----
        if (!nakAddress.contains("!")) return false; // enforce '!' usage

        String[] rawNakParts = nakAddress.split("!");
        List<String> nakParts = new ArrayList<>();
        for (String p : rawNakParts) {
            String s = p.trim();
            if (!s.isEmpty()) nakParts.add(s);
        }

        // Need at least: houseNumber + street (which can be multiple tokens)
        if (nakParts.size() < 2) return false;

        String nakHouseNumber = nakParts.get(0);
        String nakStreet = String.join(" ", nakParts.subList(1, nakParts.size()))
                                .replaceAll("\\s+", " ")
                                .trim();

        // ---- Customer address (space-separated, optional comma tail) ----
        String streetPart = customerAddress.split(",", 2)[0].trim();
        if (streetPart.isEmpty()) return false;

        String[] streetTokens = streetPart.split("\\s+", 2); // house + rest
        if (streetTokens.length < 2) return false;

        String custHouseNumber = streetTokens[0].trim();
        String custStreet = streetTokens[1].replaceAll("\\s+", " ").trim();

        // ---- Compare (case-insensitive) ----
        return custHouseNumber.equalsIgnoreCase(nakHouseNumber)
            && custStreet.equalsIgnoreCase(nakStreet);
    }
}
